# CI With Jenkins Master and Client Architecture

![CIforDevelopment!](https://lucid.app/publicSegments/view/64a259a4-f8bd-4d2a-bd47-5ed09064197b/image.png)

![JenkinsDistributedBuildResultsDeclarative!](https://lucid.app/publicSegments/view/8516f60d-e144-4757-871f-e57e6f2305af/image.png)

![JenkinsDistributedBuildResultsImperative!](https://lucid.app/publicSegments/view/1da9bc53-1f84-4e3f-b4c6-424b1187be4d/image.png)

